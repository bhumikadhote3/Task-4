
-- Create table
CREATE TABLE shipping_ecommerce (
    Customer_care_calls INT,
    Customer_rating INT,
    Prior_purchases INT,
    Discount_offered INT,
    Weight_in_gms INT,
    Warehouse_block CHAR(1),
    Mode_of_Shipment VARCHAR(20),
    Product_importance VARCHAR(20),
    Gender CHAR(1),
    Class INT
);

-- Import CSV data (example for MySQL)
-- LOAD DATA INFILE 'shipping_ecommerce.csv'
-- INTO TABLE shipping_ecommerce
-- FIELDS TERMINATED BY ','
-- LINES TERMINATED BY '\n'
-- IGNORE 1 ROWS;

-- 1. Difference between WHERE and HAVING
-- WHERE filters rows before aggregation, HAVING filters after aggregation
SELECT Warehouse_block, AVG(Weight_in_gms) AS avg_weight
FROM shipping_ecommerce
WHERE Customer_rating >= 3
GROUP BY Warehouse_block
HAVING AVG(Weight_in_gms) > 3000;

-- 2. Different types of joins (example with another table: warehouse_info)
-- Assuming warehouse_info(Warehouse_block, Location, Capacity)
SELECT s.*, w.Location
FROM shipping_ecommerce s
INNER JOIN warehouse_info w ON s.Warehouse_block = w.Warehouse_block;

SELECT s.*, w.Location
FROM shipping_ecommerce s
LEFT JOIN warehouse_info w ON s.Warehouse_block = w.Warehouse_block;

SELECT s.*, w.Location
FROM shipping_ecommerce s
RIGHT JOIN warehouse_info w ON s.Warehouse_block = w.Warehouse_block;

-- 3. Average revenue per user (ARPU) - using Discount_offered as proxy for revenue
SELECT AVG(Discount_offered) AS avg_revenue_per_user
FROM shipping_ecommerce;

-- 4. Subquery example - customers with above average prior purchases
SELECT *
FROM shipping_ecommerce
WHERE Prior_purchases > (
    SELECT AVG(Prior_purchases) FROM shipping_ecommerce
);

-- 5. Query optimization tips
-- Use indexes for frequently filtered columns
CREATE INDEX idx_rating ON shipping_ecommerce (Customer_rating);

-- Example optimized query
SELECT Warehouse_block, COUNT(*) AS shipment_count
FROM shipping_ecommerce
WHERE Customer_rating >= 4
GROUP BY Warehouse_block;

-- 6. Create a view for analysis
CREATE VIEW high_value_shipments AS
SELECT * FROM shipping_ecommerce
WHERE Discount_offered > 20 AND Customer_rating = 5;

-- 7. Handling NULL values - replace NULL ratings with average rating
SELECT COALESCE(Customer_rating, (SELECT AVG(Customer_rating) FROM shipping_ecommerce)) AS rating_fixed
FROM shipping_ecommerce;
